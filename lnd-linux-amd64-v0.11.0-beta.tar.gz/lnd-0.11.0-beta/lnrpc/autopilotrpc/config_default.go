// +build !autopilotrpc

package autopilotrpc

// Config is empty for non-autopilotrpc builds.
type Config struct{}
